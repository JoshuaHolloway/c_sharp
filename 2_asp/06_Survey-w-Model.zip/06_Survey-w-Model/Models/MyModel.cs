using System;

namespace _06_Survey_w_Model.Models
{
    public class MyModel
    {
       
    }
}