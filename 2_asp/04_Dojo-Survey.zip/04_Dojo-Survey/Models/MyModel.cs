using System;

namespace _05_ViewModel_Fun.Models
{
    public class MyModel
    {
       
    }
}